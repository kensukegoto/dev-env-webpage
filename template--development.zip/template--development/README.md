# 開発テンプレート

下記作成・記述済み

- webpack.config.js
- babel.config.js
- gulpfile.js
- package.json

`npm install`すれば開発環境が作成される。モーダルと時系列はインストールもインストール済み。